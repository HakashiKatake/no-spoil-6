(() => {
  const settingsApi = globalThis.NoSpoilSettings;
  const protection = globalThis.NoSpoilProtection;
  const { matches, createMatcher, adapterFor } = globalThis.NoSpoilRules;
  const { id: platform, selector: primary, resolveCard, extraCandidates, independent } = adapterFor(location.hostname);
  const onYouTube = /(?:^|\.)(?:youtube\.com|youtube-nocookie\.com|youtu\.be)$/.test(location.hostname);
  const fallback = "a[href],p,h1,h2,h3,h4,h5,h6,[role=heading],figure";
  const candidates = [primary, fallback, extraCandidates].filter(Boolean).join(",");
  const separate = 'shreddit-post,shreddit-comment,.thing[data-fullname],[data-comment-id]'
    + (independent ? "," + independent : "");
  const excluded = 'script,style,noscript,template,textarea,select,input,[contenteditable]:not([contenteditable=false]),[data-no-spoil-control]';
  const transient = '[role="tooltip"],tp-yt-paper-tooltip,yt-tooltip-view-model';
  const controls = 'button,[role="button"],[role="toolbar"],[role="menu"],[role="menuitem"],yt-button-shape,reel-action-bar-view-model';
  const identityAttributes = ["video-id", "post-id", "data-post-id", "data-comment-id", "data-fullname", "thingid", "data-urn"];
  const evidenceAttributes = ["alt", "title", "aria-label", "post-title", "subreddit-name", "subreddit-prefixed-name", "data-title"];
  const watchedAttributes = [...evidenceAttributes, ...identityAttributes, "href", "hidden"];
  if (platform === "linkedin") watchedAttributes.push("src", "data-view-name", "data-id", "data-activity-urn", "componentkey");
  const mediaSelector = "video,audio";
  const shortsReel = "ytd-reel-video-renderer,ytm-reel-video-renderer";
  const layoutStyles = new CSSStyleSheet();
  layoutStyles.replaceSync(`
    [data-no-spoil-covered] { isolation: isolate !important; user-select: none !important; }
    [data-no-spoil-covered] :is(img, video, canvas, iframe) { opacity: 0 !important; }
    [data-no-spoil-positioned] { position: relative !important; }
    [data-no-spoil-box] { display: block !important; }
    :root[data-no-spoil-page-blocked] body { visibility: hidden !important; opacity: 0 !important; pointer-events: none !important; }
  `);

  const overlayStyles = new CSSStyleSheet();
  overlayStyles.replaceSync(`
    :host {
      all: initial !important;
      position: absolute !important;
      inset: 0 !important;
      display: block !important;
      z-index: 2147483647 !important;
      pointer-events: none !important;
      direction: ltr !important;
      color-scheme: dark !important;
      border-radius: inherit !important;
    }
    .cover {
      position: absolute; inset: 0; display: grid; place-items: start center;
      padding: 0 6px; box-sizing: border-box; overflow: hidden;
      border: 1px solid #cfafff33; border-radius: inherit; pointer-events: auto;
      background: linear-gradient(125deg, #211534, #120e20);
      container-type: size;
    }
    @supports (backdrop-filter: blur(18px)) or (-webkit-backdrop-filter: blur(18px)) {
      .cover {
        background: linear-gradient(125deg, #211534da, #120e20d2);
        backdrop-filter: blur(24px); -webkit-backdrop-filter: blur(24px);
      }
    }
    button {
      display: inline-flex; align-items: center; justify-content: center; gap: 8px;
      box-sizing: border-box; height: 34px; max-width: 100%; padding: 0 12px;
      border: 1px solid #b593f380; border-radius: 8px; background: #201631;
      color: #fbf6ff; font: 600 12px/1 system-ui, sans-serif; white-space: nowrap;
      cursor: pointer; pointer-events: auto;
    }
    button:hover { background: #37234e; border-color: #c3a2ff; }
    button:focus-visible { outline: 2px solid #e3cfff; outline-offset: -3px; }
    .cover button { margin-top: min(14px, 14cqh); }
    .eye {
      width: 13px; height: 8px; flex: 0 0 auto; position: relative;
      border: 1.5px solid #d8baff; border-radius: 70% 70% 70% 70% / 85% 85% 85% 85%;
    }
    .eye::before {
      content: ""; position: absolute; inset: 0; margin: auto;
      width: 4px; height: 4px; border-radius: 50%; background: #d8baff;
    }
    .revealed .eye::after {
      content: ""; position: absolute; width: 17px; height: 1.5px;
      border-bottom: 1.5px solid #201631; background: #d8baff;
      transform: rotate(-35deg); left: -2px; top: 3px;
    }
    .revealed {
      position: absolute; inset: 5px auto auto 5px; height: 28px; width: 32px; padding: 0;
    }
    .revealed { width: auto; min-width: 32px; padding-inline: 7px; }
    .revealed .label:empty { display: none; }
    button:disabled { cursor: default; background: #261b34; }
    @container (max-width: 155px) {
      .cover button { width: 32px; padding: 0; }
      .cover .label { display: none; }
    }
    @container (max-height: 40px) {
      .cover button { align-self: center; margin-top: 0; height: clamp(16px, 100cqh - 4px, 30px); border-radius: 5px; }
    }
  `);

  let settings = settingsApi.normalize();
  let classify = createMatcher(settings);
  let active = false;
  let blocked = false;
  let locked = false;
  let ready = false;
  let watching = false;
  let lastUrl = location.href;
  let observedRoots = new WeakSet();
  let timer;
  const shields = new Map();
  const counted = new WeakMap();
  const observer = new MutationObserver(processMutations);

  function parentOf(element) {
    return element.parentElement ?? element.getRootNode().host ?? null;
  }

  function closestAcrossRoots(element, selector) {
    for (let current = element; current; current = parentOf(current)) {
      if (current.matches(selector)) return current;
    }
    return null;
  }

  function candidateFor(element, cardCache) {
    const post = closestAcrossRoots(element, primary);
    if (resolveCard) {
      const key = post ?? element;
      if (cardCache?.has(key)) return cardCache.get(key);
      const card = resolveCard(element, post);
      if (card) cardCache?.set(key, card);
      if (card) return card;
    }
    if (post) return post;

    const nearest = element.closest(fallback);
    if (nearest?.localName === "a") {
      return nearest.parentElement?.closest("p,h1,h2,h3,h4,h5,h6,[role=heading],figure") ?? nearest;
    }
    return nearest;
  }

  function decode(value) {
    try {
      return decodeURIComponent(value.replace(/\+/g, " "));
    } catch {
      return value;
    }
  }

  function parseLink(link) {
    try {
      const url = new URL(link, location.href);
      if (url.protocol === "https:" || url.protocol === "http:") return url;
    } catch {
      // Ignore incomplete or invalid URLs.
    }
    return null;
  }

  function linkIdentity(url) {
    if (url.hostname !== location.hostname) return "";
    if (onYouTube) {
      const id = url.pathname === "/watch"
        ? url.searchParams.get("v")
        : url.pathname.match(/^\/(?:shorts|embed|live)\/([^/]+)/)?.[1];
      return id ? "video:" + id : "";
    }
    if (platform === "bluesky") return url.pathname.match(/^\/profile\/[^/]+\/post\/[^/]+/)?.[0] ?? "";
    if (platform === "linkedin" && url.pathname.startsWith("/feed/update/")) {
      return url.pathname.match(/^\/feed\/update\/urn:li:(?:activity|ugcPost):\d+/)?.[0] ?? "";
    }
    return url.pathname.match(/\/(?:status|comments|reel|p|posts?|videos?)\/[^/]+/)?.[0] ?? "";
  }

  function readEvidence(target) {
    const text = [];
    const links = [];
    const content = [];
    const contentLabels = [];
    let identity = "";
    let permalink = "";
    for (const attr of identityAttributes) {
      const value = target.getAttribute(attr);
      if (value) {
        identity = (attr === "video-id" ? "video" : attr) + ":" + value;
        break;
      }
    }
    if (!identity && platform === "linkedin") {
      for (const attr of ["data-activity-urn", "data-id", "componentkey"]) {
        const postUrn = target.getAttribute(attr)?.match(/urn:li:(?:activity|ugcPost):\d+/)?.[0];
        if (postUrn) {
          identity = postUrn;
          break;
        }
      }
    }
    const pending = [{ node: target, control: false }];

    while (pending.length) {
      const entry = pending.pop();
      const { node } = entry;
      let { control } = entry;
      if (node.nodeType === Node.TEXT_NODE) {
        if (node.nodeValue.trim()) {
          text.push(node.nodeValue);
          if (!control) content.push(node.nodeValue);
        }
        continue;
      }
      if (node.nodeType === Node.ELEMENT_NODE) {
        if (node.matches(excluded) || node.matches(transient) || (node !== target && node.matches(separate))) continue;
        control ||= node !== target && node.matches(controls);
        for (const attr of evidenceAttributes) {
          const value = node.getAttribute(attr);
          if (!value) continue;
          text.push(value);
          if (!control) contentLabels.push(value);
        }
        const href = node.getAttribute("href");
        if (href) {
          const url = parseLink(href);
          if (url) {
            links.push(url.hostname + decode(url.pathname + url.search));
            if (!control && !permalink && !identity) permalink = linkIdentity(url);
          }
        }
        if (node.shadowRoot) pending.push({ node: node.shadowRoot, control });
      }
      for (let child = node.lastChild; child; child = child.previousSibling) {
        pending.push({ node: child, control });
      }
    }
    return {
      searchable: text.join(" ") + " " + links.join(" "),
      identity: identity || permalink,
      content: (content.length ? content : contentLabels).join(" ").replace(/\s+/g, " ").trim()
    };
  }

  function ancestorShield(target, includeRevealed = false) {
    for (let current = parentOf(target); current; current = parentOf(current)) {
      const state = shields.get(current);
      if (state && (includeRevealed || !state.revealed)) return state;
    }
    return null;
  }

  function suppressMedia(target) {
    for (const media of target.querySelectorAll(mediaSelector)) {
      if (!media.paused) media.pause();
    }
  }

  function pauseCoveredMedia(event) {
    const media = event.target;
    if (!media.matches?.(mediaSelector)) return;
    const shield = shields.size ? ancestorShield(media) : null;
    if (blocked || shield) media.pause();
  }

  function resumeShort(state) {
    if (!onYouTube || !location.pathname.startsWith("/shorts/") || !state.target.matches(shortsReel)) return;
    // Revealing a Short is also the gesture that lets its player start again.
    const activeReel = document.querySelector(":is(" + shortsReel + ")[is-active]") ?? document.querySelector(shortsReel);
    if (state.target !== activeReel) return;
    const media = state.target.querySelector("video");
    if (media) media.play().catch(() => {});
  }

  function syncInert(state) {
    for (const child of state.inert) {
      if (child.parentElement === state.target) continue;
      child.removeAttribute("inert");
      state.inert.delete(child);
    }
    for (const child of state.target.children) {
      if (child === state.host || child.hasAttribute("inert")) continue;
      child.setAttribute("inert", "");
      state.inert.add(child);
    }
    suppressMedia(state.target);
  }

  function restoreInert(state) {
    for (const child of state.inert) child.removeAttribute("inert");
    state.inert.clear();
  }

  function preventCoveredInteraction(state, event) {
    if (!state.revealed && !event.composedPath().includes(state.host)) {
      event.preventDefault();
      event.stopImmediatePropagation();
    }
  }

  function render(state, transferFocus = false) {
    const { target, shadow, cover, button, label, revealed } = state;
    const layout = getComputedStyle(target);
    const fixedPosition = layout.position === "static" || target.hasAttribute("data-no-spoil-positioned");
    const needsBox = !revealed && (layout.display === "contents" || target.hasAttribute("data-no-spoil-box"));
    target.toggleAttribute("data-no-spoil-covered", !revealed);
    target.toggleAttribute("data-no-spoil-positioned", fixedPosition);
    target.toggleAttribute("data-no-spoil-box", needsBox);
    if (revealed) {
      restoreInert(state);
      cover.remove();
      shadow.append(button);
    } else {
      shadow.append(cover);
      cover.append(button);
      syncInert(state);
    }
    button.classList.toggle("revealed", revealed);
    const subject = state.kind === "custom" ? "post" : "GTA 6 post";
    button.disabled = locked;
    button.title = locked ? "Shield locked" : revealed ? "Hide " + subject + " again" : "Reveal " + subject;
    button.setAttribute("aria-label", button.title);
    label.textContent = revealed ? "" : button.title;
    if (transferFocus) button.focus({ preventScroll: true });
  }

  function coverAgain(state, focus = false) {
    clearTimeout(state.peekTimer);
    state.deadline = 0;
    state.revealed = false;
    render(state, focus);
  }

  function updateReveal(state) {
    if (!state.revealed || !state.deadline) return;
    clearTimeout(state.peekTimer);
    const left = state.deadline - Date.now();
    if (left <= 0) {
      coverAgain(state, state.shadow.activeElement === state.button);
      scanSubtree(state.target);
      return;
    }
    state.label.textContent = Math.ceil(left / 1000) + "s";
    state.peekTimer = setTimeout(() => updateReveal(state), left % 1000 || 1000);
  }

  function addShield(target, evidence, kind) {
    const host = document.createElement("span");
    host.setAttribute("data-no-spoil-control", "");
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.adoptedStyleSheets = [overlayStyles];

    const cover = document.createElement("span");
    cover.className = "cover";
    const button = document.createElement("button");
    button.type = "button";
    const eye = document.createElement("span");
    eye.className = "eye";
    eye.setAttribute("aria-hidden", "true");
    const label = document.createElement("span");
    label.className = "label";
    button.append(eye, label);

    const state = {
      target, identity: evidence.identity, content: evidence.content, kind, host, shadow, cover, button, label,
      revealed: false, deadline: 0, inert: new Set()
    };
    state.onClick = (event) => preventCoveredInteraction(state, event);
    state.onFocus = (event) => {
      if (!state.revealed && event.target === target) button.focus({ preventScroll: true });
    };

    button.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      if (locked) return;
      if (state.revealed) {
        coverAgain(state, true);
      } else {
        state.revealed = true;
        state.deadline = settings.peekSeconds ? Date.now() + settings.peekSeconds * 1000 : 0;
        if (settings.historyEnabled) protection.record("revealed");
        render(state, true);
        updateReveal(state);
      }
      scanSubtree(target);
      if (state.revealed) resumeShort(state);
    });
    target.addEventListener("click", state.onClick, true);
    target.addEventListener("auxclick", state.onClick, true);
    target.addEventListener("focus", state.onFocus);

    shields.set(target, state);
    target.append(host);
    render(state);
  }

  function removeShield(target) {
    const state = shields.get(target);
    if (!state) return;
    shields.delete(target);
    clearTimeout(state.peekTimer);
    state.host.remove();
    target.removeAttribute("data-no-spoil-covered");
    target.removeAttribute("data-no-spoil-positioned");
    target.removeAttribute("data-no-spoil-box");
    target.removeEventListener("click", state.onClick, true);
    target.removeEventListener("auxclick", state.onClick, true);
    target.removeEventListener("focus", state.onFocus);
    restoreInert(state);
  }

  function reconcile(target, evidence, kind, count = true) {
    const state = shields.get(target);
    if (!kind || ancestorShield(target, !target.matches(separate))) {
      removeShield(target);
      return;
    }
    const itemKey = evidence.identity || evidence.content || location.pathname;
    if (ready && settings.historyEnabled && count && counted.get(target) !== itemKey) {
      counted.set(target, itemKey);
      protection.record(kind);
    }
    if (!state) {
      addShield(target, evidence, kind);
      return;
    }
    const samePost = state.identity && evidence.identity
      ? state.identity === evidence.identity
      : state.content === evidence.content;
    const kindChanged = state.kind !== kind;
    state.identity = evidence.identity;
    state.content = evidence.content;
    state.kind = kind;
    if (state.host.parentElement !== target) target.append(state.host);
    if (!samePost && state.revealed) coverAgain(state);
    else if (kindChanged && !state.revealed) render(state);
    if (!state.revealed) syncInert(state);
  }

  function inGtaFeed() {
    const path = decode(location.pathname);
    const redditTopic = path.match(/^\/r\/([^/]+)/i);
    const instagramTopic = path.match(/^\/explore\/tags\/([^/]+)/i);
    return (/(?:^|\.)reddit\.com$/.test(location.hostname) && redditTopic && matches(redditTopic[1]))
      || (/(?:^|\.)instagram\.com$/.test(location.hostname) && instagramTopic && matches(instagramTopic[1]))
      || (/(?:^|\.)(?:x\.com|twitter\.com)$/.test(location.hostname)
        && path.startsWith("/hashtag/") && matches(path.slice(9)));
  }

  function scanCandidate(target, topic, watchTargets) {
    if (!target.isConnected || watchTargets.has(target)) return;
    if (closestAcrossRoots(target, excluded)) {
      removeShield(target);
      return;
    }
    if (!target.matches(primary) && candidateFor(target) !== target) {
      removeShield(target);
      return;
    }
    if (ancestorShield(target, !target.matches(separate))) {
      removeShield(target);
      return;
    }
    const evidence = readEvidence(target);
    const kind = classify(evidence.searchable, topic && target.matches(primary));
    const wasCovered = shields.has(target) && !shields.get(target).revealed;
    reconcile(target, evidence, kind);
    if (!kind && wasCovered) scanSubtree(target);
  }

  function collect(node, found) {
    if (!node?.querySelectorAll || node.matches?.("[data-no-spoil-control]")) return;
    if (node.matches?.(candidates)) found.add(node);
    for (const candidate of node.querySelectorAll(candidates)) found.add(candidate);
    if (node.shadowRoot) collectShadow(node.shadowRoot, found);
    for (const element of node.querySelectorAll("*")) {
      if (element.shadowRoot) collectShadow(element.shadowRoot, found);
    }
  }

  function collectShadow(root, found) {
    observe(root);
    collect(root, found);
  }

  function observe(root) {
    if (observedRoots.has(root)) return;
    observedRoots.add(root);
    if (!root.adoptedStyleSheets.includes(layoutStyles)) {
      root.adoptedStyleSheets = [...root.adoptedStyleSheets, layoutStyles];
    }
    root.addEventListener("play", pauseCoveredMedia, true);
    observer.observe(root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: watchedAttributes });
  }

  function scanWatchPage() {
    const watchTargets = new Set();
    if (!onYouTube || !/^\/(?:watch|embed\/|live\/)/.test(location.pathname)) return watchTargets;
    const watch = document.querySelector("ytd-watch-flexy:not([hidden]),ytm-watch") ?? document;
    const videoId = new URL(location.href).searchParams.get("v") ?? location.pathname.split("/")[2];
    const loadedId = watch.getAttribute?.("video-id");
    const title = watch.querySelector("ytd-watch-metadata h1,#title.ytd-watch-metadata h1,.slim-video-metadata-title,.ytp-title-link");
    const player = watch.querySelector("#player-container-outer,#player-container,#movie_player");
    if (!title || (loadedId && videoId && loadedId !== videoId)) return watchTargets;

    const evidence = readEvidence(title);
    const kind = classify(evidence.searchable);
    if (videoId) evidence.identity = "video:" + videoId;
    for (const target of [player, title]) {
      if (!target) continue;
      watchTargets.add(target);
      reconcile(target, evidence, kind, target === title);
    }
    return watchTargets;
  }

  function scan(found) {
    const watchTargets = scanWatchPage();
    const topic = inGtaFeed();
    const targets = resolveCard ? new Set() : found;
    if (resolveCard) {
      const cardCache = new Map();
      for (const node of found) {
        const target = candidateFor(node, cardCache);
        if (target) targets.add(target);
        if (target !== node) removeShield(node);
      }
    }
    for (const candidate of targets) scanCandidate(candidate, topic, watchTargets);
    for (const [target] of shields) {
      if (!target.isConnected || (resolveCard && ancestorShield(target, !target.matches(separate)))) removeShield(target);
    }
  }

  function scanSubtree(root) {
    const found = new Set();
    collect(root, found);
    scan(found);
  }

  function processMutations(records) {
    if (checkRoute()) return;
    if (blocked) {
      protection.setGate(true);
      syncTitle();
      return;
    }
    if (!active) return;
    const found = new Set();
    const added = new Set();
    let pageChanged = false;
    for (const record of records) {
      const element = record.target.nodeType === Node.ELEMENT_NODE ? record.target : record.target.parentElement ?? record.target.host;
      if (element?.matches("[data-no-spoil-control]")) continue;
      const addedNodes = [...record.addedNodes].filter((node) => !node.matches?.("[data-no-spoil-control]"));
      const removedContent = [...record.removedNodes].some((node) => !node.matches?.("[data-no-spoil-control]"));
      const orphanedShield = shields.has(element) && shields.get(element).host.parentElement !== element;
      if (record.type === "childList" && !addedNodes.length && !removedContent && !orphanedShield) continue;

      pageChanged = true;
      const candidate = element && candidateFor(element);
      if (candidate) found.add(candidate);
      for (const node of addedNodes) if (node.nodeType === Node.ELEMENT_NODE) added.add(node);
    }
    if (!pageChanged) return;
    syncTitle();
    for (const node of added) {
      if (!node.isConnected) continue;
      let parent = node.parentElement;
      while (parent && !added.has(parent)) parent = parent.parentElement;
      if (!parent) collect(node, found);
    }
    scan(found);
  }

  function checkRoute() {
    if (lastUrl === location.href) return false;
    refresh();
    return true;
  }

  function syncTitle() {
    const title = protection.titleForMatching();
    protection.maskDocumentTitle(blocked || Boolean(active && settings.maskTitle && title && classify(title, inGtaFeed())));
  }

  function refresh(recheck = false) {
    const now = new Date();
    const routeChanged = lastUrl !== location.href;
    if (routeChanged) lastUrl = location.href;
    const nextBlocked = Boolean(ready && window.top === window && settingsApi.siteBlock(settings, new URL(lastUrl), now));
    const nextActive = !nextBlocked && settingsApi.status(settings, now) === "active" && !settings.disabledSites.includes(platform);
    const nextLocked = settingsApi.locked(settings, now.getTime());
    const nextWatching = nextActive || (settings.mode !== "paused" && settings.siteBlocks.length > 0);
    const filteringChanged = nextActive !== active;
    if (filteringChanged || routeChanged) for (const target of shields.keys()) removeShield(target);
    if (nextBlocked && (!blocked || routeChanged)) {
      if (settings.historyEnabled) protection.record("blocked");
      suppressMedia(document);
    }
    blocked = nextBlocked;
    active = nextActive;
    if (nextLocked !== locked) {
      locked = nextLocked;
      for (const state of shields.values()) coverAgain(state);
    }
    if (nextWatching !== watching) {
      watching = nextWatching;
      if (watching) observe(document);
      else {
        observer.disconnect();
        observedRoots = new WeakSet();
      }
    }
    protection.setGate(blocked);
    syncTitle();
    if (active && (filteringChanged || routeChanged || recheck === true)) scanSubtree(document);
    for (const state of [...shields.values()]) {
      if (state.deadline && state.deadline <= now.getTime()) updateReveal(state);
    }

    clearTimeout(timer);
    const minute = 60000 - Date.now() % 60000 + 20;
    timer = setTimeout(refresh, locked ? Math.min(minute, settings.lockUntil - now.getTime() + 20) : minute);
  }

  function applySettings(value) {
    ready = true;
    settings = value;
    classify = createMatcher(settings);
    refresh(true);
  }

  settingsApi.subscribe(applySettings);
  refresh();
  settingsApi.read().then((value) => {
    if (!ready) applySettings(value);
  }).catch(() => {
    // A failed read keeps the shield in its default mode.
    refresh();
  });
  document.addEventListener("visibilitychange", refresh);
  document.addEventListener("DOMContentLoaded", () => {
    refresh(true);
  }, { once: true });
  if (resolveCard) {
    document.addEventListener("load", (event) => {
      if (!active || !event.target.matches?.(extraCandidates)) return;
      const card = candidateFor(event.target);
      if (card) scan(new Set([card]));
    }, true);
  }
  window.addEventListener("focus", refresh);
  window.addEventListener("pageshow", refresh);
  window.addEventListener("popstate", checkRoute);
  window.addEventListener("hashchange", checkRoute);
  window.navigation?.addEventListener("navigatesuccess", checkRoute);
  settingsApi.api?.runtime?.onMessage.addListener((message, _sender, reply) => {
    if (message?.ns6 === "tab-state") {
      reply({ active, blocked, platform });
    } else if (message?.ns6 === "cover-tab") {
      let count = 0;
      for (const state of shields.values()) {
        if (state.revealed) {
          coverAgain(state);
          count++;
        }
      }
      reply({ count });
    }
  });
})();
